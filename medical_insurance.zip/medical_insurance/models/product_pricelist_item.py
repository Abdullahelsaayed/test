from odoo import models, fields, api


class ProductPricelistItem(models.Model):
    _inherit = 'product.pricelist.item'
    _description = 'product pricelist item extend'

    barcode = fields.Char(related='product_tmpl_id.barcode')


class ProductPricelist(models.Model):
    _inherit = 'product.pricelist'

    insurance_company = fields.Many2one('res.partner', string='Insurance Company')
