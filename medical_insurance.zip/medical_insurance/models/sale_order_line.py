from odoo import models, fields, api


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    barcode = fields.Char(related='product_id.barcode')
    charge_rate = fields.Float(string='Charge Rate')
    charge_rate_type = fields.Selection([('f', 'Fixed'), ('p', 'Percentage')], string='Charge Rate type')
    claim = fields.Float(string='Claim')

    @api.onchange('barcode', 'order_partner_id')
    def charge_rate_func(self):
        charges = self.env['insurance.charges'].search([('partner_id', '=', self.order_partner_id.id)])
        for charge in charges:
            if self.barcode == charge.charge_code:
                self.charge_rate_type = charge.charge_rate_type
                if self.charge_rate_type == 'f':
                    self.charge_rate = charge.charge_rate
                else:
                    self.charge_rate = (self.price_unit * charge.charge_rate / 100.0)


    @api.depends('product_uom_qty', 'price_unit', 'barcode', 'charge_rate', 'price_unit','order_partner_id')
    def _compute_amount(self):
        if self.order_partner_id.insurance_status == 'v':
            for line in self:
                if line.charge_rate:
                    line.price_subtotal = line.charge_rate * line.product_uom_qty
                    line.claim = (line.price_unit - line.price_subtotal) * line.product_uom_qty
                    print(self.order_partner_id.insurance_status)
        else:
            super()._compute_amount()
