from odoo import fields, models, api
from datetime import date


class CustomerMedicalInsurance(models.Model):
    _inherit = 'res.partner'
    _description = 'add medical insurance'
    is_insurance_company = fields.Boolean()
    insurance_company = fields.Many2one('res.partner', string="Insurance Company")
    insurance_card_number = fields.Char(string='Card Number')
    st_date = fields.Date(string="Start Date")
    exp_date = fields.Date(string="Exp Date")
    insurance_status = fields.Selection([('v', 'Valid'), ('not_valid', 'Not Valid')],compute='compute_insurance_status')
    insurance_charges_ids = fields.One2many('insurance.charges', 'partner_id')
    insurance_attachments_ids = fields.One2many('insurance.attachments', 'partner_id')

    # insurance_status = fields.Selection([('insured', 'Insured'), ('not_insured', 'Not Insured')], compute="compute_insurance_status")

    @api.depends()
    def compute_insurance_status(self):
        for rec in self:
            if (rec.insurance_card_number) and (rec.exp_date >= date.today()):
                rec.insurance_status = 'v'
            else:
                rec.insurance_status = 'not_valid'


# charges card
class InsuranceCharges(models.Model):
    _name = 'insurance.charges'
    _description = " insurance charges"

    partner_id = fields.Many2one('res.partner')
    charge_code = fields.Char(string='Charge Code')
    charge_name = fields.Char(string='Charge Name')
    charge_rate = fields.Float(string='Charge Rate')
    charge_rate_type = fields.Selection([('f', 'Fixed'), ('p', 'Percentage')], string='Charge Rate type')


# attachments
class InsuranceAttachments(models.Model):
    _name = 'insurance.attachments'
    _description = 'Add Insurance Attachments '

    partner_id = fields.Many2one('res.partner')
    attachment = fields.Binary(string='Attachment')
