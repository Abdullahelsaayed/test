from odoo import models, fields, api
from datetime import date


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    insurance_company = fields.Many2one(related='partner_id.insurance_company')
    insurance_status = fields.Selection(related='partner_id.insurance_status')
    total_claim = fields.Monetary(string='Total Claim', compute='get_total_claim')

    # def compute_charges(self):
    #     patient

    def get_total_claim(self):
        if self.insurance_status== 'v':
            total_claim = 0
            lines = self.env['sale.order.line'].search([('order_id', '=', self.id)])
            for line in lines:
                total_claim += line.claim
            self.total_claim = total_claim
        else:
            self.total_claim = 0


