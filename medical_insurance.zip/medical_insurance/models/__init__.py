from . import product_pricelist_item, customer_medical_insurance, sale_order
from . import sale_order_line
