# -*- coding: utf-8 -*-
{
    'name': "Medical Insurance",

    'summary': """ Medical Insurance module """,

    'description': """
        Medical Insurance for Patient
    """,

    'author': "Nile Live",
    'website': "http://www.nilelive.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Medical',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'sale_management'],

    # always loaded
    'data': [
        'security/medical_insurance_security.xml',
        'security/ir.model.access.csv',
        'views/insurance_company_view.xml',
        'views/pricelist_item.xml',
        'views/customer_medical_insurance_view.xml',
        'views/sale_order.xml',
        'views/medical_insurance_view.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
