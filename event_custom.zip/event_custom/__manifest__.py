{
    'name': "Event Custom",
    'version': '1.0',
    'depends': ['base', 'sale', 'hr', 'sale_management', 'event', 'website', 'website_event'],
    'author': "Abdullah",

    'category': 'Category',
    'description': """
    Custom Event Attendees
    """,
    # data files always loaded at installation
    'data': [
        'views/event_registration.xml',
        # 'views/website_registration.xml',

    ],

    # data files containing optionally loaded demonstration data
    'demo': [
        # 'demo/demo_data.xml',
    ],
    'installable': True,
    'auto_install': False,
    'license': 'AGPL-3',
}
