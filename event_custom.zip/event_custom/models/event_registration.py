from odoo import fields, models


class EventRegistration(models.Model):
    _inherit = 'event.registration'

    team_name = fields.Char(string="Team Name", translate=True)
    level = fields.Selection([('b', 'Beginner'), ('m', 'Intermediate'), ('p', 'Professional')])
    gender = fields.Selection([('m', 'Male'), ('f', 'Female')])
    #
    player_one = fields.Char(string="Player One")
    player_one_phone = fields.Char(string="Phone")
    player_one_age = fields.Char(string="Age")
    player_one_nationality = fields.Char(string="Nationality")
    player_one_email = fields.Char(string="Email")
    #
    player_two = fields.Char(string="Player Two")
    player_two_phone = fields.Char(string="Phone")
    player_two_age = fields.Char(string="Age")
    player_two_nationality = fields.Char(string="Nationality")
    player_two_email = fields.Char(string="Email")
